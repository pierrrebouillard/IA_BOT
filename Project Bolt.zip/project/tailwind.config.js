/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'megabet': {
          50: '#D7C7FF',
          100: '#e0effe',
          200: '#bae0fd',
          300: '#B199ED',
          400: '#7440F4',
          500: '#0c8de4',
          600: '#7440F4',
          700: '#06003B',
          800: '#064b83',
          900: '#06003B',
        },
        'betting': {
          light: '#f8fafc',
          dark: '#1e293b',
        }
      },
      fontFamily: {
        'sans': ['Helvetica Neue', 'Helvetica', 'Arial', 'sans-serif'],
        'display': ['Helvetica Neue', 'Helvetica', 'Arial', 'sans-serif']
      },
      boxShadow: {
        'card': '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
        'hover': '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
      },
      borderRadius: {
        'xl': '1rem',
        '2xl': '1.5rem',
      }
    },
  },
  plugins: [],
};