import React, { useState } from 'react';
import { MessageSquare, AlertTriangle, Calendar, Goal, Hash, Trophy, ChevronRight, User, Bot, Atom } from 'lucide-react';
import { FolderRoot as Football, ShoppingBasket as Basketball, Baseline as Baseball, Tent as Tennis, Car as F1, Flag as Rugby } from 'lucide-react';

type Message = {
  text: string;
  isBot: boolean;
};

type BetType = 'goalscorer' | 'exactScore' | 'goals' | 'winner';

type Match = {
  id: string;
  homeTeam: string;
  awayTeam: string;
  date: string;
  time: string;
  players?: string[];
};

const SPORTS = [
  { name: 'Football', icon: Football },
  { name: 'Basketball', icon: Basketball },
  { name: 'Tennis', icon: Tennis },
  { name: 'Baseball', icon: Baseball },
  { name: 'Formule 1', icon: F1 },
  { name: 'Rugby', icon: Rugby }
];

const LEAGUES = {
  Football: ['Ligue 1', 'Premier League', 'La Liga', 'Champions League'],
  Basketball: ['NBA', 'EuroLeague'],
  Tennis: ['ATP Tour', 'WTA Tour'],
  Baseball: ['MLB', 'NPB'],
  'Formule 1': ['F1 World Championship'],
  Rugby: ['Top 14', 'Champions Cup', 'Six Nations']
};

const FUTURE_MATCHES: Record<string, Match[]> = {
  'Ligue 1': [
    { 
      id: '1', 
      homeTeam: 'PSG', 
      awayTeam: 'Marseille', 
      date: '2024-03-31', 
      time: '20:45',
      players: ['Mbappé', 'Dembélé', 'Aubameyang', 'Verratti']
    },
    { 
      id: '2', 
      homeTeam: 'Lyon', 
      awayTeam: 'Monaco', 
      date: '2024-04-03', 
      time: '21:00',
      players: ['Lacazette', 'Ben Yedder', 'Tolisso', 'Golovin']
    }
  ],
  'Premier League': [
    { 
      id: '3', 
      homeTeam: 'Manchester City', 
      awayTeam: 'Arsenal', 
      date: '2024-03-31', 
      time: '16:30',
      players: ['Haaland', 'Saka', 'De Bruyne', 'Martinelli']
    }
  ],
  'F1 World Championship': [
    {
      id: '4',
      homeTeam: 'Australian GP',
      awayTeam: 'Melbourne',
      date: '2024-03-24',
      time: '05:00'
    }
  ],
  'Top 14': [
    {
      id: '5',
      homeTeam: 'Toulouse',
      awayTeam: 'Stade Français',
      date: '2024-03-23',
      time: '21:00'
    }
  ]
};

const BET_OPTIONS = {
  goalscorer: ['First Goalscorer', 'Anytime Goalscorer', 'Last Goalscorer'],
  exactScore: ['Full Time', 'First Half'],
  goals: ['Over/Under', 'Both Teams to Score'],
  winner: ['Match Winner', 'Double Chance']
};

function App() {
  const [messages, setMessages] = useState<Message[]>([
    { text: "Bonjour! Je suis Bêt, votre assistant de paris sportifs. Sélectionnez un sport pour commencer.", isBot: true }
  ]);
  const [selectedSport, setSelectedSport] = useState<string | null>(null);
  const [selectedLeague, setSelectedLeague] = useState<string | null>(null);
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);
  const [selectedBetType, setSelectedBetType] = useState<BetType | null>(null);
  const [userMessage, setUserMessage] = useState('');

  const handleSportSelection = (sport: string) => {
    setSelectedSport(sport);
    setSelectedLeague(null);
    setSelectedMatch(null);
    setSelectedBetType(null);
    setMessages(prev => [...prev, 
      { text: `Vous avez sélectionné ${sport}`, isBot: false },
      { text: `Excellent choix! Choisissez un championnat de ${sport}:`, isBot: true }
    ]);
  };

  const handleLeagueSelection = (league: string) => {
    setSelectedLeague(league);
    setSelectedMatch(null);
    setSelectedBetType(null);
    setMessages(prev => [...prev,
      { text: `Vous avez sélectionné ${league}`, isBot: false },
      { text: 'Sélectionnez un match à venir:', isBot: true }
    ]);
  };

  const handleMatchSelection = (match: Match) => {
    setSelectedMatch(match);
    setSelectedBetType(null);
    setMessages(prev => [...prev,
      { text: `Match sélectionné: ${match.homeTeam} vs ${match.awayTeam}`, isBot: false },
      { text: 'Quel type de pari souhaitez-vous placer?', isBot: true }
    ]);
  };

  const handleBetTypeSelection = (betType: BetType) => {
    setSelectedBetType(betType);
    let message = '';
    switch(betType) {
      case 'goalscorer':
        message = `Pour ${selectedMatch?.homeTeam} vs ${selectedMatch?.awayTeam}, voici les buteurs possibles: ${selectedMatch?.players?.join(', ')}`;
        break;
      case 'exactScore':
        message = 'Quel score exact prévoyez-vous?';
        break;
      case 'goals':
        message = 'Combien de buts prévoyez-vous dans ce match?';
        break;
      case 'winner':
        message = 'Quelle équipe pensez-vous va gagner?';
        break;
    }
    setMessages(prev => [...prev,
      { text: `Type de pari: ${betType}`, isBot: false },
      { text: message, isBot: true }
    ]);
  };

  const handleMessageSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userMessage.trim()) return;

    setMessages(prev => [...prev, 
      { text: userMessage, isBot: false },
      { text: `J'ai analysé votre prédiction pour ${selectedMatch?.homeTeam} vs ${selectedMatch?.awayTeam}. Voici mon analyse: Les statistiques récentes suggèrent que c'est un pari intéressant. Je vous conseille de rester prudent et de ne pas miser plus que ce que vous pouvez vous permettre de perdre.`, isBot: true }
    ]);
    setUserMessage('');
  };

  return (
    <div className="min-h-screen bg-betting-light flex">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-lg">
        <div className="p-4 bg-megabet-600">
          <h1 className="text-xl font-display font-bold text-white flex items-center">
            <Atom className="mr-2 h-6 w-6 text-megabet-50" />
            Bêt
          </h1>
        </div>
        <div className="p-2">
          {SPORTS.map(({ name, icon: Icon }) => (
            <div key={name}>
              <button
                onClick={() => handleSportSelection(name)}
                className={`w-full text-left p-3 rounded-lg flex items-center space-x-3 transition-colors duration-200 ${
                  selectedSport === name ? 'bg-megabet-50 text-megabet-700' : 'hover:bg-gray-50'
                }`}
              >
                <Icon className="h-5 w-5" />
                <span className="font-medium">{name}</span>
                <ChevronRight className="h-4 w-4 ml-auto" />
              </button>
              {selectedSport === name && (
                <div className="ml-6 mt-2 space-y-1">
                  {LEAGUES[name as keyof typeof LEAGUES].map(league => (
                    <button
                      key={league}
                      onClick={() => handleLeagueSelection(league)}
                      className={`w-full text-left p-2 rounded-md text-sm transition-colors duration-200 ${
                        selectedLeague === league ? 'bg-megabet-50 text-megabet-700' : 'hover:bg-gray-50'
                      }`}
                    >
                      {league}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Warning Banner */}
        <div className="bg-megabet-50 border-l-4 border-megabet-400 p-4">
          <div className="flex items-center">
            <AlertTriangle className="h-5 w-5 text-megabet-600 mr-2" />
            <p className="text-sm text-megabet-700 font-medium">
              Les paris peuvent être addictifs. Pariez de manière responsable et respectez la législation locale.
            </p>
          </div>
        </div>

        <div className="flex-1 p-4">
          <div className="card h-full flex flex-col">
            {/* Chat Messages */}
            <div className="flex-1 p-4 overflow-y-auto space-y-4">
              {messages.map((message, index) => (
                <div
                  key={index}
                  className={`flex ${message.isBot ? 'justify-start' : 'justify-end'}`}
                >
                  <div className={`flex items-start space-x-2 max-w-[80%]`}>
                    {message.isBot ? (
                      <div className="w-8 h-8 rounded-full bg-megabet-100 flex items-center justify-center">
                        <Bot className="h-5 w-5 text-megabet-600" />
                      </div>
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center order-2">
                        <User className="h-5 w-5 text-gray-600" />
                      </div>
                    )}
                    <div
                      className={`p-3 rounded-lg ${
                        message.isBot
                          ? 'bg-gray-100 text-betting-dark'
                          : 'bg-megabet-600 text-white order-1'
                      }`}
                    >
                      {message.text}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Selection Area */}
            <div className="border-t p-4">
              {selectedMatch && !selectedBetType && (
                <div className="grid grid-cols-4 gap-3">
                  <button
                    onClick={() => handleBetTypeSelection('goalscorer')}
                    className="flex flex-col items-center p-4 bg-megabet-50 hover:bg-megabet-100 rounded-lg transition-colors duration-200"
                  >
                    <Goal className="h-6 w-6 text-megabet-600 mb-2" />
                    <span className="text-sm font-medium text-megabet-700">Buteur</span>
                  </button>
                  <button
                    onClick={() => handleBetTypeSelection('exactScore')}
                    className="flex flex-col items-center p-4 bg-megabet-50 hover:bg-megabet-100 rounded-lg transition-colors duration-200"
                  >
                    <Hash className="h-6 w-6 text-megabet-600 mb-2" />
                    <span className="text-sm font-medium text-megabet-700">Score Exact</span>
                  </button>
                  <button
                    onClick={() => handleBetTypeSelection('goals')}
                    className="flex flex-col items-center p-4 bg-megabet-50 hover:bg-megabet-100 rounded-lg transition-colors duration-200"
                  >
                    <Trophy className="h-6 w-6 text-megabet-600 mb-2" />
                    <span className="text-sm font-medium text-megabet-700">Nombre de Buts</span>
                  </button>
                  <button
                    onClick={() => handleBetTypeSelection('winner')}
                    className="flex flex-col items-center p-4 bg-megabet-50 hover:bg-megabet-100 rounded-lg transition-colors duration-200"
                  >
                    <Trophy className="h-6 w-6 text-megabet-600 mb-2" />
                    <span className="text-sm font-medium text-megabet-700">Vainqueur</span>
                  </button>
                </div>
              )}

              {selectedLeague && !selectedMatch && (
                <div className="space-y-2">
                  {FUTURE_MATCHES[selectedLeague]?.map(match => (
                    <button
                      key={match.id}
                      onClick={() => handleMatchSelection(match)}
                      className="w-full bg-white border border-megabet-200 hover:border-megabet-300 text-betting-dark font-medium py-3 px-4 rounded-lg transition-colors duration-200 flex justify-between items-center hover:bg-megabet-50"
                    >
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-2 text-megabet-600" />
                        <span>{match.homeTeam} vs {match.awayTeam}</span>
                      </div>
                      <div className="text-sm text-gray-500">
                        {match.date} {match.time}
                      </div>
                    </button>
                  ))}
                </div>
              )}

              {selectedBetType && (
                <form onSubmit={handleMessageSubmit} className="flex space-x-2">
                  <input
                    type="text"
                    value={userMessage}
                    onChange={(e) => setUserMessage(e.target.value)}
                    placeholder="Entrez votre prédiction..."
                    className="input"
                  />
                  <button
                    type="submit"
                    className="btn-primary"
                  >
                    Envoyer
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;